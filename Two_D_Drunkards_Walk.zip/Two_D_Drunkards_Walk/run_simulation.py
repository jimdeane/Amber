# -*- coding: utf-8 -*-
"""
Created on Mon Apr  8 13:43:14 2024

@author: jim
"""
from walk_space import two_d_space
from scipy.stats import linregress
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import random
import sys

iterations = 10
steps = 40

survivors = np.zeros(steps + 1)

# create the data frame for the results
df = pd.DataFrame(columns=['Index','Hit', 'Alive'])
walkspace = two_d_space(11,400)

for i in range(iterations):  
    for j in range(steps):
        direction = random.choice(["left","right"])
        
        result = walkspace.move_drunkard(direction)
        print(result)
        if result[0] == "error":
            sys.exit()
        if result[0] == True: # True means run out of moves
            df.loc[i] = [i, 0, True]
        else:
            df.loc[i] = [i, result[0], False]
        
print(df)       
        
     
